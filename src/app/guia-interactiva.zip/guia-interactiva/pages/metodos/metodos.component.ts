import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { MetodosService } from './metodo.service';

@Component({
  selector: 'app-metodos',
  templateUrl: './metodos.component.html',
  styleUrls: ['./metodos.component.css']
})
export class MetodosComponent implements OnInit {
  metodo: any;

  constructor(
    private route: ActivatedRoute,
    private metodosService: MetodosService,
    private location: Location
  ) { }

  // metodos.component.ts
  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const num = params.get('id') || params.get('num');
      if (num) {
        this.metodo = this.metodosService.getMetodoByNum(num.toString());
      }
    });
  }

  volver(): void {
    this.location.back();
  }
}