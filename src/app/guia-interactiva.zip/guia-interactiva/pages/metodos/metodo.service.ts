import { Injectable } from '@angular/core';
import { RECURSOS_DATABASE } from '../../recursos.data';

export interface PasoMetodo {
  numero: number;
  titulo: string;
  descripcion: string;
}

export interface FichaMetodo {
  num: string;
  nombre: string;
  fase: string;
  subetapa?: string;
  definicion: string;
  herramientas: string[];
  pasos: PasoMetodo[];
}

@Injectable({
  providedIn: 'root'
})
export class MetodosService {

  // metodo.service.ts
  getMetodoByNum(num: string) {
    const metodoData = RECURSOS_DATABASE.metodos.find(
      (m: any) => String(m.num) === String(num) || String(m.id) === String(num)
    );

    if (!metodoData) return undefined;

    const instrumentosTexto = Array.isArray(metodoData.instrumento)
      ? metodoData.instrumento.join(', ')
      : 'No especificado';

    return {
      num: metodoData.num,
      nombre: metodoData.nombre,
      fase: metodoData.etapa ? metodoData.etapa.join(', ') : 'Fase General',
      subetapa: metodoData.subetapa ? metodoData.subetapa.join(', ') : '',
      definicion: metodoData.finalidad,
      herramientas: metodoData.insumo && metodoData.insumo.length > 0
        ? metodoData.insumo
        : ['Instrumentos: ' + instrumentosTexto],
      pasos: [
        { numero: 1, titulo: 'Producto esperado', descripcion: metodoData.producto || 'N/A' },
        { numero: 2, titulo: 'Instrumentos aplicables', descripcion: instrumentosTexto }
      ]
    };
  }
}